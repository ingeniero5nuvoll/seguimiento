<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;


require  '../vendor/autoload.php';
require  '../src/config/db.php';


$app = new \Slim\App;

//Ruta areas
require  '../src/rutas/areas.php';
require  '../src/rutas/materias.php';
require  '../src/rutas/estados.php';
require  '../src/rutas/canales.php';
require  '../src/rutas/funcionarios.php';
require  '../src/rutas/alertas.php';
require  '../src/rutas/regionales.php';
require  '../src/rutas/tipoalertas.php';
require  '../src/rutas/solicitudes.php';


$app->run();