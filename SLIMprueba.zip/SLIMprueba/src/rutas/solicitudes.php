<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

$app = new \Slim\App;

// GET Listar todas las solicitudes
$app->get('/api/solicitudes/lSolicitudes', function(Request $request, Response $response){
    $sql ="SELECT * FROM solicitudes";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);
        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen SOLICITUDES en la BD.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// GET Listar todas las solicitudes por ID
$app->get('/api/solicitudes/rSolicitudes/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $sql ="SELECT * FROM solicitudes WHERE id = $id";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);

        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen solicitudes en la BD con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// POST Crear una nueva solicitud
$app->post('/api/solicitudes/cSolicitudes', function(Request $request, Response $response){
    $fecha = $request->getParam('fecha');
    $persona = $request->getParam('persona');
    $cargo = $request->getParam('cargo');
    $email = $request->getParam('email');
    $telefono = $request->getParam('telefono');
    $id_prueba = $request->getParam('id_prueba');
    $id_regional = $request->getParam('id_regional');
    $tipo = $request->getParam('tipo');
    $id_materia = $request->getParam('id_materia');
    $id_canal = $request->getParam('id_canal');
    $alcance = $request->getParam('alcance');
    $novedades = $request->getParam('novedades');
    $directrices = $request->getParam('directrices');
    $objetivos = $request->getParam('objetivos');
    $colaborador = $request->getParam('colaborador');
    $fcapacitacion = $request->getParam('fcapacitacion');
    $pregunta = $request->getParam('pregunta');


    $sql ="INSERT INTO solicitudes (fecha,persona,cargo,email,telefono,id_prueba,id_regional,tipo,
    id_materia,id_canal,alcance,novedades,directrices,objetivos,colaborador,fcapacitacion,
    pregunta) VALUES 
    (:fecha,:persona,:cargo,:email,:telefono,:id_prueba,:id_regional,:tipo,
    :id_materia,:id_canal,:alcance,:novedades,:directrices,:objetivos,:colaborador,:fcapacitacion,
    :pregunta)";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':fecha', $fecha);
        $resultado->bindParam(':persona', $persona);
        $resultado->bindParam(':cargo', $cargo);
        $resultado->bindParam(':email', $email);
        $resultado->bindParam(':telefono', $telefono);
        $resultado->bindParam(':id_prueba', $id_prueba);
        $resultado->bindParam(':id_regional', $id_regional);
        $resultado->bindParam(':tipo', $tipo);
        $resultado->bindParam(':id_materia', $id_materia);
        $resultado->bindParam(':id_canal', $id_canal);
        $resultado->bindParam(':alcance', $alcance);
        $resultado->bindParam(':novedades', $novedades);
        $resultado->bindParam(':directrices', $directrices);
        $resultado->bindParam(':objetivos', $objetivos);
        $resultado->bindParam(':colaborador', $colaborador);
        $resultado->bindParam(':fcapacitacion', $fcapacitacion);
        $resultado->bindParam(':pregunta', $pregunta);
        

        $resultado->execute();
        echo json_encode("Nueva SOLICITUD guardada.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// PUT Modificar una area
$app->put('/api/solicitudes/uSolicitudes/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $fecha = $request->getParam('fecha');
    $persona = $request->getParam('persona');
    $cargo = $request->getParam('cargo');
    $email = $request->getParam('email');
    $telefono = $request->getParam('telefono');
    $id_prueba = $request->getParam('id_prueba');
    $id_regional = $request->getParam('id_regional');
    $tipo = $request->getParam('tipo');
    $id_materia = $request->getParam('id_materia');
    $id_canal = $request->getParam('id_canal');
    $alcance = $request->getParam('alcance');
    $novedades = $request->getParam('novedades');
    $directrices = $request->getParam('directrices');
    $objetivos = $request->getParam('objetivos');
    $colaborador = $request->getParam('colaborador');
    $fcapacitacion = $request->getParam('fcapacitacion');
    $pregunta = $request->getParam('pregunta');

    $sql ="UPDATE solicitudes SET 
    fecha = :fecha, 
    persona = :persona,
    cargo = :cargo,
    email = :email,
    telefono = :telefono,
    id_prueba = :id_prueba,
    id_regional = :id_regional,
    tipo = :tipo,
    id_materia = :id_materia,
    id_canal = :id_canal,
    alcance = :alcance,
    novedades = :novedades,
    directrices = :directrices,
    objetivos = :objetivos,
    colaborador = :colaborador,
    fcapacitacion = :fcapacitacion,
    pregunta = :pregunta
    WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':fecha', $fecha);
        $resultado->bindParam(':persona', $persona);
        $resultado->bindParam(':cargo', $cargo);
        $resultado->bindParam(':email', $email);
        $resultado->bindParam(':telefono', $telefono);
        $resultado->bindParam(':id_prueba', $id_prueba);
        $resultado->bindParam(':id_regional', $id_regional);
        $resultado->bindParam(':tipo', $tipo);
        $resultado->bindParam(':id_materia', $id_materia);
        $resultado->bindParam(':id_canal', $id_canal);
        $resultado->bindParam(':alcance', $alcance);
        $resultado->bindParam(':novedades', $novedades);
        $resultado->bindParam(':directrices', $directrices);
        $resultado->bindParam(':objetivos', $objetivos);
        $resultado->bindParam(':colaborador', $colaborador);
        $resultado->bindParam(':fcapacitacion', $fcapacitacion);
        $resultado->bindParam(':pregunta', $pregunta);

        $resultado->execute();
        echo json_encode("Solicitud modificada.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});


// DELETE Borrar una alerta
$app->delete('/api/solicitudes/dSolicitudes/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');

    $sql ="DELETE FROM solicitudes WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);
        $resultado->execute();

        if($resultado->rowCount() > 0){
            echo json_encode("Solicitud eliminada.");
        }else{
            echo json_encode("No existe Solicitud con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});