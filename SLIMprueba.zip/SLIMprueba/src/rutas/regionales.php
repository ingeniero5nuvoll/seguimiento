<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

$app = new \Slim\App;

// GET Listar todos los regionales
$app->get('/api/regionales/lRegionales', function(Request $request, Response $response){
    $sql ="SELECT * FROM regionales";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);
        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen REGIONALES en la BD.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// GET Listar todos los Regionales por ID
$app->get('/api/regionales/rRegionales/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $sql ="SELECT * FROM regionales WHERE id = $id";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);

        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen REGIONALES en la BD con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// POST Crear un nuevo rEGIONAL
$app->post('/api/regionales/cRegionales', function(Request $request, Response $response){
    $nombre = $request->getParam('nombre');
    $activo = $request->getParam('activo');

    $sql ="INSERT INTO regionales (nombre,activo) VALUES 
    (:nombre, :activo)";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':nombre', $nombre);
        $resultado->bindParam(':activo', $activo);

        $resultado->execute();
        echo json_encode("Nuevo REGIONAL guardada.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// PUT Modificar un Regional
$app->put('/api/regionales/uRegionales/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $nombre = $request->getParam('nombre');
    $activo = $request->getParam('activo');

    $sql ="UPDATE regionales SET
    nombre = :nombre,
    activo = :activo
    WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':nombre', $nombre);
        $resultado->bindParam(':activo', $activo);

        $resultado->execute();
        echo json_encode("Regionales modificado.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});


// DELETE Borrar una area
$app->delete('/api/regionales/dRegionales/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');

    $sql ="DELETE FROM regionales WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);
        $resultado->execute();

        if($resultado->rowCount() > 0){
            echo json_encode("Regional eliminado.");
        }else{
            echo json_encode("No existen REGIONALES con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});