<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

$app = new \Slim\App;

// GET Listar todos los estados
$app->get('/api/estados', function(Request $request, Response $response){
    $sql ="SELECT * FROM estados";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);
        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen ESTADOS en la BD.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// GET Listar todos los estados por ID
$app->get('/api/estados/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $sql ="SELECT * FROM estados WHERE id = $id";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);

        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen ESTADOS en la BD con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// POST Crear una nueva area
$app->post('/api/estados/cEstados', function(Request $request, Response $response){
    $nombre = $request->getParam('nombre');
    $activo = $request->getParam('activo');

    $sql ="INSERT INTO estados (nombre,activo) VALUES 
    (:nombre, :activo)";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':nombre', $nombre);
        $resultado->bindParam(':activo', $activo);

        $resultado->execute();
        echo json_encode("Nuevo ESTADO guardada.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// PUT Modificar una area
$app->put('/api/estados/uEstados/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $nombre = $request->getParam('nombre');
    $activo = $request->getParam('activo');

    $sql ="UPDATE estados SET
    nombre = :nombre,
    activo = :activo
    WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':nombre', $nombre);
        $resultado->bindParam(':activo', $activo);

        $resultado->execute();
        echo json_encode("ESTADO modificado.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});


// DELETE Borrar una area
$app->delete('/api/estados/dEstados/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');

    $sql ="DELETE FROM estados WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);
        $resultado->execute();

        if($resultado->rowCount() > 0){
            echo json_encode("ESTADO eliminada.");
        }else{
            echo json_encode("No existen ESTADOS con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});