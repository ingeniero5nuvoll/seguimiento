<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

$app = new \Slim\App;

// GET Listar todas las alertas
$app->get('/api/alertas/lAlertas', function(Request $request, Response $response){
    $sql ="SELECT * FROM alertas";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);
        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen ALERTAS en la BD.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// GET Listar todas las alertas por ID
$app->get('/api/alertas/rAlertas/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $sql ="SELECT * FROM alertas WHERE id = $id";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);

        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen ALERTAS en la BD con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// POST Crear una nueva alerta
$app->post('/api/alertas/cAlertas', function(Request $request, Response $response){
    $id_materia = $request->getParam('id_materia');
    $id_estado = $request->getParam('id_estado');
    $fecha = $request->getParam('fecha');
    $descripcion = $request->getParam('descripcion');
    $id_tipoalerta = $request->getParam('id_tipoalerta');
    $activo = $request->getParam('activo');
    $fcreated = $request->getParam('fcreated');
    $fmodified = $request->getParam('fmodified');
    $ucreated = $request->getParam('ucreated');
    $umodified = $request->getParam('umodified');

    $sql ="INSERT INTO alertas (id_materia,id_estado,fecha,descripcion,id_tipoalerta,activo,
    fcreated,fmodified,ucreated,umodified) VALUES 
    (:id_materia,:id_estado,:fecha,:descripcion,:id_tipoalerta,:activo,:fcreated
    ,:fmodified,:ucreated,:umodified)";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':id_materia', $id_materia);
        $resultado->bindParam(':id_estado', $id_estado);
        $resultado->bindParam(':fecha', $fecha);
        $resultado->bindParam(':descripcion', $descripcion);
        $resultado->bindParam(':id_tipoalerta', $id_tipoalerta);
        $resultado->bindParam(':activo', $activo);
        $resultado->bindParam(':fcreated', $fcreated);
        $resultado->bindParam(':fmodified', $fmodified);
        $resultado->bindParam(':ucreated', $ucreated);
        $resultado->bindParam(':umodified', $umodified);

        $resultado->execute();
        echo json_encode("Nueva ALERTA guardada.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// PUT Modificar una area
$app->put('/api/alertas/uAlertas/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $id_materia = $request->getParam('id_materia');
    $id_estado = $request->getParam('id_estado');
    $fecha = $request->getParam('fecha');
    $descripcion = $request->getParam('descripcion');
    $id_tipoalerta = $request->getParam('id_tipoalerta');
    $activo = $request->getParam('activo');
    $fcreated = $request->getParam('fcreated');
    $fmodified = $request->getParam('fmodified');
    $ucreated = $request->getParam('ucreated');
    $umodified = $request->getParam('umodified');

    $sql ="UPDATE alertas SET
    id_materia = :id_materia,
    id_estado = :id_estado,
    fecha = :fecha,
    descripcion = :descripcion,
    id_tipoalerta = :id_tipoalerta,
    activo = :activo,
    fcreated = :fcreated,
    fmodified = :fmodified,
    ucreated = :ucreated,
    umodified = :umodified
    WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':id_materia', $id_materia);
        $resultado->bindParam(':id_estado', $id_estado);
        $resultado->bindParam(':fecha', $fecha);
        $resultado->bindParam(':descripcion', $descripcion);
        $resultado->bindParam(':id_tipoalerta', $id_tipoalerta);
        $resultado->bindParam(':activo', $activo);
        $resultado->bindParam(':fcreated', $fcreated);
        $resultado->bindParam(':fmodified', $fmodified);
        $resultado->bindParam(':ucreated', $ucreated);
        $resultado->bindParam(':umodified', $umodified);

        $resultado->execute();
        echo json_encode("Alerta modificada.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});


// DELETE Borrar una alerta
$app->delete('/api/alertas/dAlertas/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');

    $sql ="DELETE FROM alertas WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);
        $resultado->execute();

        if($resultado->rowCount() > 0){
            echo json_encode("Alerta eliminada.");
        }else{
            echo json_encode("No existe ALerta con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});