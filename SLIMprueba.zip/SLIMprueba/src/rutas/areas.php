<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

$app = new \Slim\App;

// GET Listar todas las areas
$app->get('/api/areas/lAreas', function(Request $request, Response $response){
    $sql ="SELECT * FROM areas";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);
        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen areas en la BD.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// GET Listar todas las areas por ID
$app->get('/api/areas/rAreas/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $sql ="SELECT * FROM areas WHERE id = $id";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);

        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen areas en la BD con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// POST Crear una nueva area
$app->post('/api/areas/cAreas', function(Request $request, Response $response){
    $nombre = $request->getParam('nombre');
    $activo = $request->getParam('activo');

    $sql ="INSERT INTO areas (nombre,activo) VALUES 
    (:nombre, :activo)";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':nombre', $nombre);
        $resultado->bindParam(':activo', $activo);

        $resultado->execute();
        echo json_encode("Nueva AREA guardada.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// PUT Modificar una area
$app->put('/api/areas/uAreas/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $nombre = $request->getParam('nombre');
    $activo = $request->getParam('activo');

    $sql ="UPDATE areas SET
    nombre = :nombre,
    activo = :activo
    WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':nombre', $nombre);
        $resultado->bindParam(':activo', $activo);

        $resultado->execute();
        echo json_encode("Area modificada.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});


// DELETE Borrar una area
$app->delete('/api/areas/dAreas/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');

    $sql ="DELETE FROM areas WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);
        $resultado->execute();

        if($resultado->rowCount() > 0){
            echo json_encode("Area eliminada.");
        }else{
            echo json_encode("No existe cliente con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});