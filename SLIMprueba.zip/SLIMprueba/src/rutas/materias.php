<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

$app = new \Slim\App;

// GET Listar todas las areas
$app->get('/api/materias/lMaterias', function(Request $request, Response $response){
    $sql ="SELECT * FROM materias";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);
        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen MATERIAS en la BD.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// GET Listar todas las areas por ID
$app->get('/api/materias/rMaterias/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $sql ="SELECT * FROM areas WHERE id = $id";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);

        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen areas en la BD con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// POST Crear una nueva area
$app->post('/api/materias/cMaterias', function(Request $request, Response $response){
    $nombre = $request->getParam('nombre');
    $id_area = $request->getParam('id_area');
    $alcance = $request->getParam('alcance');
    $tipo = $request->getParam('tipo');
    $id_aprobado = $request->getParam('id_aprobado');
    $tmateria = $request->getParam('tmateria');
    $activo = $request->getParam('activo');
    $fcreated = $request->getParam('fcreated');
    $fmodified = $request->getParam('fmodified');
    $ucreated = $request->getParam('ucreated');
    $umodified = $request->getParam('umodified');

    $sql ="INSERT INTO materias (nombre,id_area,alcance,tipo,id_aprobado,tmateria,activo,fcreated,
    fmodified,ucreated,umodified) VALUES 
    (:nombre,:id_area,:alcance,:tipo,:id_aprobado,:tmateria,:activo,:fcreated,
    :fmodified,:ucreated,:umodified)";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':nombre', $nombre);
        $resultado->bindParam(':id_area', $id_area);
        $resultado->bindParam(':alcance', $alcance);
        $resultado->bindParam(':tipo', $tipo);
        $resultado->bindParam(':id_aprobado', $id_aprobado);
        $resultado->bindParam(':tmateria', $tmateria);
        $resultado->bindParam(':activo', $activo);
        $resultado->bindParam(':fcreated', $fcreated);
        $resultado->bindParam(':fmodified', $fmodified);
        $resultado->bindParam(':ucreated', $ucreated);
        $resultado->bindParam(':umodified', $umodified);


        $resultado->execute();
        echo json_encode("Nueva MATERIA guardada.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// PUT Modificar una area
$app->put('/api/materias/uMaterias/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $nombre = $request->getParam('nombre');
    $id_area = $request->getParam('id_area');
    $alcance = $request->getParam('alcance');
    $tipo = $request->getParam('tipo');
    $id_aprobado = $request->getParam('id_aprobado');
    $tmateria = $request->getParam('tmateria');
    $activo = $request->getParam('activo');
    $fcreated = $request->getParam('fcreated');
    $fmodified = $request->getParam('fmodified');
    $ucreated = $request->getParam('ucreated');
    $umodified = $request->getParam('umodified');


    $sql ="UPDATE materias SET
    nombre = :nombre,
    id_area = :id_area,
    alcance = :alcance,
    tipo = :tipo,
    id_aprobado = :id_aprobado,
    tmateria = :tmateria,
    activo = :activo,
    fcreated = :fcreated,
    fmodified = :fmodified,
    ucreated = :ucreated,
    umodified = :umodified
    WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':nombre', $nombre);
        $resultado->bindParam(':id_area', $id_area);
        $resultado->bindParam(':alcance', $alcance);
        $resultado->bindParam(':tipo', $tipo);
        $resultado->bindParam(':id_aprobado', $id_aprobado);
        $resultado->bindParam(':tmateria', $tmateria);
        $resultado->bindParam(':activo', $activo);
        $resultado->bindParam(':fcreated', $fcreated);
        $resultado->bindParam(':fmodified', $fmodified);
        $resultado->bindParam(':ucreated', $ucreated);
        $resultado->bindParam(':umodified', $umodified);

        $resultado->execute();
        echo json_encode("MATERIA modificada.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});


// DELETE Borrar una area
$app->delete('/api/materias/dMaterias/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $sql ="DELETE FROM materias WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);
        $resultado->execute();

        if($resultado->rowCount() > 0){
            echo json_encode("MATERIA eliminada.");
        }else{
            echo json_encode("No existen MATERIAS con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});