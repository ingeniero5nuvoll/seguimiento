<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

$app = new \Slim\App;

// GET Listar todos los funcionarios
$app->get('/api/funcionarios/lFuncionarios', function(Request $request, Response $response){
    $sql ="SELECT * FROM funcionarios";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);
        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen FUNCIONARIOS en la BD.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// GET Listar todos los Funcionarios por ID
$app->get('/api/funcionarios/rFuncionarios/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $sql ="SELECT * FROM funcionarios WHERE id = $id";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);

        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen FUNCIONARIOS en la BD con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// POST Crear un nuevo Funcionario
$app->post('/api/funcionarios/cFuncionarios', function(Request $request, Response $response){
    $nombre = $request->getParam('nombre');
    $cargo = $request->getParam('cargo');
    $usuario = $request->getParam('usuario');
    $clave = $request->getParam('clave');
    $activo = $request->getParam('activo');

    $sql ="INSERT INTO funcionarios (nombre,cargo,usuario,clave,activo) VALUES 
    (:nombre,:cargo,:usuario,:clave,:activo)";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':nombre', $nombre);
        $resultado->bindParam(':cargo', $cargo);
        $resultado->bindParam(':usuario', $usuario);
        $resultado->bindParam(':clave', $clave);
        $resultado->bindParam(':activo', $activo);

        $resultado->execute();
        echo json_encode("Nuevo FUNCIONARIO guardado.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// PUT Modificar un Funcionario
$app->put('/api/funcionarios/uFuncionarios/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $nombre = $request->getParam('nombre');
    $cargo = $request->getParam('cargo');
    $usuario = $request->getParam('usuario');
    $clave = $request->getParam('clave');
    $activo = $request->getParam('activo');

    $sql ="UPDATE funcionarios SET
    nombre = :nombre,
    cargo = :cargo,
    usuario = :usuario,
    clave = :clave,
    activo = :activo
    WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':nombre', $nombre);
        $resultado->bindParam(':cargo', $cargo);
        $resultado->bindParam(':usuario', $usuario);
        $resultado->bindParam(':clave', $clave);
        $resultado->bindParam(':activo', $activo);

        $resultado->execute();
        echo json_encode("FUNCIONARIO modificado.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});


// DELETE Borrar una funcionario
$app->delete('/api/funcionarios/dFuncionarios/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');

    $sql ="DELETE FROM funcionarios WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);
        $resultado->execute();

        if($resultado->rowCount() > 0){
            echo json_encode("Funcionario eliminado.");
        }else{
            echo json_encode("No existen FUNCIONARIOS con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});


// PUT Modificar un Funcionario
$app->put('/api/funcionarios/uFuncionariosClave/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $clave = $request->getParam('clave');

    $sql ="UPDATE funcionarios SET
    clave = :clave
    WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':clave', $clave);

        $resultado->execute();
        echo json_encode("clave del FUNCIONARIO modificada.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});
