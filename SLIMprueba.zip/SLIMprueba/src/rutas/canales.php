<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

$app = new \Slim\App;

// GET Listar todos los canales
$app->get('/api/canales/lCanales', function(Request $request, Response $response){
    $sql ="SELECT * FROM canales";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);
        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen CANALES en la BD.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// GET Listar todos los Canales por ID
$app->get('/api/canales/rCanales/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $sql ="SELECT * FROM canales WHERE id = $id";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->query($sql);

        if($resultado->rowCount() > 0){
            $area = $resultado->fetchAll(PDO::FETCH_OBJ);
            echo json_encode($area);
        }else{
            echo json_encode("No existen CANALES en la BD con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// POST Crear un nuevo Canal
$app->post('/api/canales/cCanales', function(Request $request, Response $response){
    $nombre = $request->getParam('nombre');
    $activo = $request->getParam('activo');

    $sql ="INSERT INTO canales (nombre,activo) VALUES 
    (:nombre, :activo)";
    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':nombre', $nombre);
        $resultado->bindParam(':activo', $activo);

        $resultado->execute();
        echo json_encode("Nuevo CANAL guardada.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});

// PUT Modificar un Canal
$app->put('/api/canales/uCanales/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $nombre = $request->getParam('nombre');
    $activo = $request->getParam('activo');

    $sql ="UPDATE canales SET
    nombre = :nombre,
    activo = :activo
    WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);

        $resultado->bindParam(':nombre', $nombre);
        $resultado->bindParam(':activo', $activo);

        $resultado->execute();
        echo json_encode("CANAL modificado.");

        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});


// DELETE Borrar una area
$app->delete('/api/canales/dCanales/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');

    $sql ="DELETE FROM canales WHERE id = $id";

    try{
        $db = new db();
        $db = $db->conectDB();
        $resultado = $db->prepare($sql);
        $resultado->execute();

        if($resultado->rowCount() > 0){
            echo json_encode("Canal eliminado.");
        }else{
            echo json_encode("No existen CANALES con este ID.");
        }
        $resultado = null;
        $db = null;
    }catch(PDOException $e){
        echo '{"error" : {"text":'.$e->getMessage().'}';
    }
});